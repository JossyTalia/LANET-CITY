
function loginAdmin() {
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;
  if(user === 'admin' && pass === 'lanet2025') {
    alert('Welcome Admin!');
    return true;
  } else {
    alert('Invalid login');
    return false;
  }
}
