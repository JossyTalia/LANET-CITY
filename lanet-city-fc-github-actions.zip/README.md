# Lanet City FC Website
This is the official website for Lanet City FC. Hosted on GitHub Pages.

- Homepage
- Team
- Fixtures
- Gallery
- Registration Form
- Admin Panel (username: admin / password: lanet2025)
